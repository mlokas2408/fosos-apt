"""Snap layout picker (Win+Z) and window geometry helpers."""

from __future__ import annotations

from dataclasses import dataclass

import gi

gi.require_version("Gdk", "3.0")
gi.require_version("Gtk", "3.0")
gi.require_version("Wnck", "3.0")
from gi.repository import Gdk, GLib, Gtk, Wnck

from .panel import HEIGHT, SKIP_TYPES, x_timestamp
from .ui import add_classes, button, clear, label


@dataclass(frozen=True)
class Slot:
    """Normalized work-area slot: x,y,w,h in 0..1 fractions."""

    x: float
    y: float
    w: float
    h: float
    label: str = ""


@dataclass(frozen=True)
class Layout:
    name: str
    slots: tuple[Slot, ...]


LAYOUTS: tuple[Layout, ...] = (
    Layout(
        "Two columns",
        (
            Slot(0, 0, 0.5, 1, "Left"),
            Slot(0.5, 0, 0.5, 1, "Right"),
        ),
    ),
    Layout(
        "Three columns",
        (
            Slot(0, 0, 0.25, 1, "Left"),
            Slot(0.25, 0, 0.5, 1, "Center"),
            Slot(0.75, 0, 0.25, 1, "Right"),
        ),
    ),
    Layout(
        "Four corners",
        (
            Slot(0, 0, 0.5, 0.5, "Top left"),
            Slot(0.5, 0, 0.5, 0.5, "Top right"),
            Slot(0, 0.5, 0.5, 0.5, "Bottom left"),
            Slot(0.5, 0.5, 0.5, 0.5, "Bottom right"),
        ),
    ),
    Layout(
        "Left tall",
        (
            Slot(0, 0, 0.5, 1, "Left"),
            Slot(0.5, 0, 0.5, 0.5, "Top right"),
            Slot(0.5, 0.5, 0.5, 0.5, "Bottom right"),
        ),
    ),
    Layout(
        "Right tall",
        (
            Slot(0, 0, 0.5, 0.5, "Top left"),
            Slot(0, 0.5, 0.5, 0.5, "Bottom left"),
            Slot(0.5, 0, 0.5, 1, "Right"),
        ),
    ),
)


def _gdk_rect(x: int, y: int, width: int, height: int) -> Gdk.Rectangle:
    # Gdk.Rectangle(x, y, w, h) ignores its arguments (PyGObject boxed init).
    rect = Gdk.Rectangle()
    rect.x = int(x)
    rect.y = int(y)
    rect.width = max(1, int(width))
    rect.height = max(1, int(height))
    return rect


def work_area_for_point(root_x: int, root_y: int) -> Gdk.Rectangle:
    display = Gdk.Display.get_default()
    monitor = display.get_monitor_at_point(root_x, root_y)
    if monitor is None:
        monitor = display.get_primary_monitor() or display.get_monitor(0)
    if monitor is None:
        return _gdk_rect(0, 0, 1, 1)
    area = monitor.get_geometry()
    return _gdk_rect(area.x, area.y, area.width, max(1, area.height - HEIGHT))


def work_area_for_window(window: Wnck.Window) -> Gdk.Rectangle:
    x, y, w, h = window.get_geometry()
    return work_area_for_point(x + w // 2, y + h // 2)


# GTK/Electron often map with program-specified location 0,0 and a stub size.
_ORIGIN_TOLERANCE = 8
_TINY_WIDTH = 160
_TINY_HEIGHT = 120


def repair_startup_geometry(window: Wnck.Window) -> bool:
    """Center/grow windows that mapped as a stub in the top-left corner.

    Skips docks, dialogs, maximized/fullscreen windows, and edge-snapped
    layouts so restored or tiled geometry is left alone.
    """
    if window.get_window_type() != Wnck.WindowType.NORMAL:
        return False
    if window.is_skip_tasklist() or window.get_window_type() in SKIP_TYPES:
        return False
    if window.is_maximized() or window.is_fullscreen() or window.is_minimized():
        return False
    try:
        x, y, w, h = window.get_geometry()
    except Exception:  # noqa: BLE001 - window may vanish before we run
        return False
    area = work_area_for_window(window)
    # A 0×0 work area used to be sent to the window manager, which collapsed
    # the new window into a stub and left it in the top-left corner.
    if area.width < 64 or area.height < 64:
        return False
    if is_snapped(window, area):
        return False
    at_origin = abs(x - area.x) <= _ORIGIN_TOLERANCE and abs(y - area.y) <= _ORIGIN_TOLERANCE
    too_small = (w < _TINY_WIDTH and h < _TINY_HEIGHT) or min(w, h) < 64
    if not at_origin and not too_small:
        return False
    if too_small:
        new_w = min(area.width, max(640, int(area.width * 0.55)))
        new_h = min(area.height, max(420, int(area.height * 0.55)))
    else:
        new_w, new_h = min(w, area.width), min(h, area.height)
    if new_w < 64 or new_h < 64:
        return False
    new_x = area.x + max(0, (area.width - new_w) // 2)
    new_y = area.y + max(0, (area.height - new_h) // 2)
    if (new_x, new_y, new_w, new_h) == (x, y, w, h):
        return False
    gravity = Wnck.WindowGravity.STATIC
    mask = (
        Wnck.WindowMoveResizeMask.X
        | Wnck.WindowMoveResizeMask.Y
        | Wnck.WindowMoveResizeMask.WIDTH
        | Wnck.WindowMoveResizeMask.HEIGHT
    )
    window.set_geometry(gravity, mask, new_x, new_y, new_w, new_h)
    return True


def slot_rect(area: Gdk.Rectangle, slot: Slot) -> tuple[int, int, int, int]:
    x = area.x + int(round(area.width * slot.x))
    y = area.y + int(round(area.height * slot.y))
    # Size from remaining fraction so adjacent slots share edges without gaps.
    x2 = area.x + int(round(area.width * (slot.x + slot.w)))
    y2 = area.y + int(round(area.height * (slot.y + slot.h)))
    return x, y, max(1, x2 - x), max(1, y2 - y)


def target_window(screen: Wnck.Screen | None = None) -> Wnck.Window | None:
    screen = screen or Wnck.Screen.get_default()
    screen.force_update()
    window = screen.get_active_window()
    if window is not None and not window.is_skip_tasklist() and window.get_window_type() not in SKIP_TYPES:
        return window
    # When the shell popup steals focus, use the previously active client.
    for candidate in reversed(screen.get_windows_stacked()):
        if candidate.is_skip_tasklist() or candidate.get_window_type() in SKIP_TYPES:
            continue
        if candidate.is_minimized():
            continue
        return candidate
    return None


# Last floating geometry before a snap/maximize, keyed by XID.
_NORMAL_GEOM: dict[int, tuple[int, int, int, int]] = {}
_SNAP_TOLERANCE = 24

# Edge/corner slots shared with EdgeSnap and keyboard tiling.
LEFT = Slot(0, 0, 0.5, 1, "Left")
RIGHT = Slot(0.5, 0, 0.5, 1, "Right")
TOP_LEFT = Slot(0, 0, 0.5, 0.5, "Top left")
TOP_RIGHT = Slot(0.5, 0, 0.5, 0.5, "Top right")
BOTTOM_LEFT = Slot(0, 0.5, 0.5, 0.5, "Bottom left")
BOTTOM_RIGHT = Slot(0.5, 0.5, 0.5, 0.5, "Bottom right")
EDGE_SLOTS: tuple[Slot, ...] = (LEFT, RIGHT, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT)


def remember_normal_geometry(window: Wnck.Window) -> None:
    """Store floating size before snap/maximize (skip if already snapped/max)."""
    if window.is_maximized():
        return
    if is_snapped(window):
        return
    xid = window.get_xid()
    _NORMAL_GEOM[xid] = window.get_geometry()
    _prune_geometry_cache()


def _prune_geometry_cache() -> None:
    screen = Wnck.Screen.get_default()
    screen.force_update()
    alive = {w.get_xid() for w in screen.get_windows()}
    for xid in list(_NORMAL_GEOM):
        if xid not in alive:
            del _NORMAL_GEOM[xid]


def is_snapped(window: Wnck.Window, area: Gdk.Rectangle | None = None) -> bool:
    """True when geometry matches an edge or Win+Z layout slot."""
    if window.is_maximized():
        return False
    area = area or work_area_for_window(window)
    x, y, w, h = window.get_geometry()
    slots: list[Slot] = list(EDGE_SLOTS)
    for layout in LAYOUTS:
        slots.extend(layout.slots)
    seen: set[tuple[float, float, float, float]] = set()
    for slot in slots:
        key = (slot.x, slot.y, slot.w, slot.h)
        if key in seen:
            continue
        seen.add(key)
        sx, sy, sw, sh = slot_rect(area, slot)
        if (
            abs(x - sx) <= _SNAP_TOLERANCE
            and abs(y - sy) <= _SNAP_TOLERANCE
            and abs(w - sw) <= _SNAP_TOLERANCE
            and abs(h - sh) <= _SNAP_TOLERANCE
        ):
            return True
    return False


def apply_slot(window: Wnck.Window, slot: Slot, area: Gdk.Rectangle | None = None) -> None:
    area = area or work_area_for_window(window)
    remember_normal_geometry(window)
    x, y, w, h = slot_rect(area, slot)
    if window.is_maximized():
        window.unmaximize()
    if window.is_minimized():
        stamp = int(GLib.get_monotonic_time() / 1000)
        window.activate(stamp)
    gravity = Wnck.WindowGravity.STATIC
    mask = (
        Wnck.WindowMoveResizeMask.X
        | Wnck.WindowMoveResizeMask.Y
        | Wnck.WindowMoveResizeMask.WIDTH
        | Wnck.WindowMoveResizeMask.HEIGHT
    )
    window.set_geometry(gravity, mask, x, y, w, h)


def restore_normal_geometry(window: Wnck.Window) -> bool:
    """Restore saved floating geometry. Returns True if restored."""
    xid = window.get_xid()
    geom = _NORMAL_GEOM.get(xid)
    if window.is_maximized():
        window.unmaximize()
        return True
    if geom is None:
        # Fallback: centered ~60% of work area.
        area = work_area_for_window(window)
        w = max(320, int(area.width * 0.6))
        h = max(240, int(area.height * 0.6))
        x = area.x + (area.width - w) // 2
        y = area.y + (area.height - h) // 2
        geom = (x, y, w, h)
    if window.is_minimized():
        stamp = int(GLib.get_monotonic_time() / 1000)
        window.activate(stamp)
    gravity = Wnck.WindowGravity.STATIC
    mask = (
        Wnck.WindowMoveResizeMask.X
        | Wnck.WindowMoveResizeMask.Y
        | Wnck.WindowMoveResizeMask.WIDTH
        | Wnck.WindowMoveResizeMask.HEIGHT
    )
    x, y, w, h = geom
    window.set_geometry(gravity, mask, x, y, w, h)
    return True


def snap_left(window: Wnck.Window | None = None) -> None:
    window = window or target_window()
    if window is None:
        return
    apply_slot(window, LEFT)
    stamp = int(GLib.get_monotonic_time() / 1000)
    window.activate(stamp)


def snap_right(window: Wnck.Window | None = None) -> None:
    window = window or target_window()
    if window is None:
        return
    apply_slot(window, RIGHT)
    stamp = int(GLib.get_monotonic_time() / 1000)
    window.activate(stamp)


def snap_down(window: Wnck.Window | None = None) -> None:
    """Win+Down: unmaximize / unsnap, else minimize."""
    window = window or target_window()
    if window is None:
        return
    stamp = int(GLib.get_monotonic_time() / 1000)
    if window.is_maximized():
        remember_normal_geometry(window)  # no-op when maximized; Openbox keeps size
        window.unmaximize()
        window.activate(stamp)
        return
    if is_snapped(window):
        restore_normal_geometry(window)
        window.activate(stamp)
        return
    window.minimize()


def snap_maximize(window: Wnck.Window | None = None) -> None:
    window = window or target_window()
    if window is None:
        return
    remember_normal_geometry(window)
    stamp = int(GLib.get_monotonic_time() / 1000)
    window.maximize()
    window.activate(stamp)


def move_window_to_workspace(window: Wnck.Window, index: int) -> None:
    screen = Wnck.Screen.get_default()
    screen.force_update()
    if index < 0 or index >= screen.get_workspace_count():
        return
    workspace = screen.get_workspace(index)
    if workspace is None:
        return
    window.move_to_workspace(workspace)


class SnapAssist:
    """After placing one slot, offer remaining slots to the next focused window."""

    def __init__(self, shell) -> None:
        self.shell = shell
        self.pending: list[Slot] = []
        self.area: Gdk.Rectangle | None = None
        self._exclude_xid: int | None = None
        self._handler_id = 0

    def arm(self, remaining: list[Slot], area: Gdk.Rectangle, placed: Wnck.Window) -> None:
        self.clear()
        if not remaining:
            return
        self.pending = list(remaining)
        self.area = area
        self._exclude_xid = placed.get_xid()
        screen = Wnck.Screen.get_default()
        self._handler_id = screen.connect("active-window-changed", self._on_active)

    def clear(self) -> None:
        if self._handler_id:
            try:
                Wnck.Screen.get_default().disconnect(self._handler_id)
            except Exception:
                pass
            self._handler_id = 0
        self.pending = []
        self.area = None
        self._exclude_xid = None

    def _on_active(self, screen: Wnck.Screen, _previous=None) -> None:
        if not self.pending or self.area is None:
            self.clear()
            return
        window = screen.get_active_window()
        if window is None:
            return
        if window.get_xid() == self._exclude_xid:
            return
        if window.is_skip_tasklist() or window.get_window_type() in SKIP_TYPES:
            return
        slot = self.pending.pop(0)
        apply_slot(window, slot, self.area)
        self._exclude_xid = window.get_xid()
        if not self.pending:
            self.clear()
            self.shell.notify_self("Snap layouts", "Layout filled.")
        else:
            left = len(self.pending)
            self.shell.notify_self(
                "Snap layouts",
                f"Placed window. Focus {left} more window{'s' if left != 1 else ''} to fill.",
            )


class SnapLayouts(Gtk.Window):
    """FosOS card with layout diagrams; click a cell to place the focused window."""

    def __init__(self, shell) -> None:
        super().__init__(type=Gtk.WindowType.POPUP)
        self.shell = shell
        self.assist = SnapAssist(shell)
        self.set_type_hint(Gdk.WindowTypeHint.POPUP_MENU)
        self.set_resizable(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        add_classes(self, "fos-root", "fos-popup")
        self.add_events(Gdk.EventMask.KEY_PRESS_MASK | Gdk.EventMask.BUTTON_PRESS_MASK)
        self.connect("key-press-event", self._on_key)
        self.connect("button-press-event", self._on_button)
        self.connect("grab-broken-event", lambda *_a: self.hide_picker())

        self.frame = add_classes(Gtk.Box(orientation=Gtk.Orientation.VERTICAL), "fos-card", "fos-snap-layouts")
        self.add(self.frame)
        header = add_classes(Gtk.Box(), "fos-card-header")
        header.pack_start(label("Snap layouts", "fos-title"), False, False, 0)
        self.frame.pack_start(header, False, False, 0)
        body = add_classes(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12), "fos-card-content")
        self.frame.pack_start(body, False, False, 0)
        tip = label("Pick a region for the focused window. Remaining regions fill next.", "fos-small", "fos-muted")
        tip.set_line_wrap(True)
        body.pack_start(tip, False, False, 0)
        self.grid = Gtk.Box(spacing=12)
        body.pack_start(self.grid, False, False, 0)
        self._grabbed = False
        self._build()

    def _build(self) -> None:
        clear(self.grid)
        for layout in LAYOUTS:
            card = add_classes(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6), "fos-snap-layout")
            card.pack_start(label(layout.name, "fos-small", "fos-muted", xalign=0.5), False, False, 0)
            diagram = Gtk.Fixed()
            diagram.set_size_request(120, 72)
            add_classes(diagram, "fos-snap-diagram")
            for index, slot in enumerate(layout.slots):
                cell = add_classes(Gtk.Button(), "fos-btn", "outline", "fos-snap-cell")
                cell.set_can_focus(False)
                cell.set_tooltip_text(slot.label or layout.name)
                cell.connect("clicked", lambda _b, lay=layout, idx=index: self._pick(lay, idx))
                px = int(round(120 * slot.x)) + 2
                py = int(round(72 * slot.y)) + 2
                pw = max(20, int(round(120 * slot.w)) - 4)
                ph = max(16, int(round(72 * slot.h)) - 4)
                cell.set_size_request(pw, ph)
                diagram.put(cell, px, py)
            card.pack_start(diagram, False, False, 0)
            self.grid.pack_start(card, False, False, 0)

        actions = Gtk.Box(spacing=8)
        maximize = button("Maximize", variant="outline", size="sm")
        maximize.connect("clicked", lambda _b: self._maximize())
        actions.pack_start(maximize, False, False, 0)
        clear_btn = button("Clear assist", variant="ghost", size="sm")
        clear_btn.connect("clicked", lambda _b: self._clear_assist())
        actions.pack_start(clear_btn, False, False, 0)
        self.frame.pack_start(actions, False, False, 0)

    def toggle(self) -> None:
        if self.get_visible():
            self.hide_picker()
        else:
            self.open_picker()

    def open_picker(self) -> None:
        self.shell.close_popups(keep="snaplayouts")
        if target_window() is None:
            self.shell.notify_self("Snap layouts", "Focus a window first.")
            return
        self.show_all()
        self._show_centered()
        GLib.idle_add(self._grab)

    def hide_picker(self) -> None:
        if self._grabbed:
            Gdk.Display.get_default().get_default_seat().ungrab()
            self._grabbed = False
        self.hide()

    def _show_centered(self) -> None:
        display = Gdk.Display.get_default()
        monitor = display.get_primary_monitor() or display.get_monitor(0)
        area = monitor.get_geometry()
        _minimum, natural = self.get_preferred_size()
        width = natural.width
        height = natural.height
        self.resize(width, height)
        x = area.x + (area.width - width) // 2
        y = area.y + max(24, (area.height - HEIGHT - height) // 3)
        self.move(x, y)
        self.present()

    def _grab(self) -> bool:
        window = self.get_window()
        if window is None or not self.get_visible():
            return False
        seat = Gdk.Display.get_default().get_default_seat()
        status = seat.grab(window, Gdk.SeatCapabilities.ALL, True, None, None, None)
        self._grabbed = status == Gdk.GrabStatus.SUCCESS
        return False

    def _pick(self, layout: Layout, index: int) -> None:
        window = target_window()
        if window is None:
            self.hide_picker()
            return
        area = work_area_for_window(window)
        slot = layout.slots[index]
        apply_slot(window, slot, area)
        remaining = [s for i, s in enumerate(layout.slots) if i != index]
        self.assist.arm(remaining, area, window)
        self.hide_picker()
        if remaining:
            self.shell.notify_self(
                "Snap layouts",
                f"Placed in {slot.label or 'region'}. Focus another window to fill the next region.",
            )

    def _maximize(self) -> None:
        window = target_window()
        if window is None:
            self.hide_picker()
            return
        self.assist.clear()
        stamp = x_timestamp(self.shell.panel) if self.shell.panel is not None else int(GLib.get_monotonic_time() / 1000)
        window.maximize()
        window.activate(stamp)
        self.hide_picker()

    def _clear_assist(self) -> None:
        self.assist.clear()
        self.shell.notify_self("Snap layouts", "Fill assist cleared.")

    def _on_key(self, _widget, event: Gdk.EventKey) -> bool:
        if event.keyval == Gdk.KEY_Escape:
            self.hide_picker()
            return True
        return False

    def _on_button(self, _widget, event: Gdk.EventButton) -> bool:
        # Clicks on children are handled by buttons; empty chrome dismisses.
        if event.window == self.get_window():
            self.hide_picker()
            return True
        return False
