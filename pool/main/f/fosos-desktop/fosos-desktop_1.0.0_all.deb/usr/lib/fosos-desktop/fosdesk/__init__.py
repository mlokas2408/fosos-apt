"""FosOS Desktop, the default FosOS session."""

VERSION = "1.0.0"
