# FosOS Desktop recovery and rollback

FosOS Desktop is the default login session. XFCE stays installed as a
supported fallback. Use this guide when the custom session fails, or when you
want to roll back to XFCE for one account or for the whole machine.

## Switch to XFCE at the next login

1. Sign out (Start → Sign out), or press Ctrl+Alt+F2 and reboot if the
   graphical session is stuck.
2. On the LightDM greeter, open the session menu (usually a gear or
   desktop icon near the password field).
3. Choose **Xfce Session**.
4. Sign in.

LightDM remembers the last session per account in `~/.dmrc`. Choosing XFCE
once keeps it until you pick **FosOS Desktop** again.

## Restore FosOS Desktop as the default

For one account, choose **FosOS Desktop** on the greeter.

For the machine default (new accounts and greeter fallback):

```bash
# /etc/lightdm/lightdm.conf.d/50-fosos-default-session.conf
[Seat:*]
user-session=fosos-desktop
```

That file ships in the `fosos-desktop` package. To force XFCE as the machine
default instead:

```bash
sudo tee /etc/lightdm/lightdm.conf.d/60-fosos-xfce-fallback.conf >/dev/null <<'EOF'
[Seat:*]
user-session=xfce
EOF
```

Remove that override to return to the package default.

## Shell crashed (no taskbar)

Openbox may still be running with open windows. Openbox keybindings still
work:

| Keys | Action |
| --- | --- |
| Ctrl+Alt+T | Terminal |
| Super+E | Files |
| openbox --exit | Sign out |

If the shell gave up after repeated crashes, FosOS opens a recovery terminal
and writes `~/.config/fosos-desktop/shell-failed`. In that terminal:

```bash
fosos-shell
```

If the shell keeps dying, sign out and use **Xfce Session**, then update:

```bash
fos update
fos upgrade
```

Or with APT:

```bash
sudo apt update
sudo apt install --reinstall fosos-desktop
```

## Lock screen will not unlock

1. Switch to a text console with Ctrl+Alt+F2.
2. Sign in with your account.
3. End the locker and return to the graphical seat:

```bash
pkill -x fosos-lock
sudo loginctl unlock-sessions
```

4. Switch back with Ctrl+Alt+F1. If the session is still stuck, reboot from
   the console: `sudo systemctl reboot`.

## Live image recovery console

On the live image, Ctrl+Alt+F2 opens a console for the `user` account
(password `live`). Ctrl+Alt+F1 returns to the desktop.

## Roll back a bad package upgrade

If a `fosos-desktop` upgrade breaks the session:

```bash
# From XFCE or a TTY
apt-cache policy fosos-desktop
sudo apt install fosos-desktop=<previous-version>
```

Prefer promoting only packages that passed the [testing guide](TESTING.md)
soak. ISOs are for fresh installs; day-to-day fixes come through APT.

## When to file a bug

Collect `~/.config/fosos-desktop/shell-failed`, the output of
`journalctl --user -b`, and whether XFCE still works. Reinstall or USB tests
must not use a disk that holds data you need.
